﻿
namespace Calculator
{
    class Termn
    {
        public string numbers;  
    }
}
